/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

#include <stdlib.h>

#include <stdio.h>

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#define DIR_PIN GPIO_PIN_1
#define DIR_PORT GPIOA
#define STEP_PIN GPIO_PIN_0
#define STEP_PORT GPIOA
#define TURN180 200
#define TURN360 400
#define TOTALDIST 34.5
#define INIDIST 10
#define OBJ1 1
#define OBJ2 2
/**
 * Lines
 */
#define PRINT_LINE 155
#define EVENT_HORIZON 140
#define ROW_LINE 80
#define EXCESS_LINE 30
#define PIXY_RATIO 1.5
#define DATUM 50
#define PRINTSIZE 30
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef enum __pixyChecksumstate{
	PIXY_RESULT_OK = 1,
	PIXY_RESULT_ERROR = 0
}PixyChecksumState;

typedef enum __printHeadMovement{
	IDLE = 0,
	GO_TO_PRINTING_ZONE = 1,
	DO_PRINTING_MOVEMENT_FRONT_BACK = 2
}PrintHeadMovementStatus;

typedef struct __printHeadStatus{
	PrintHeadMovementStatus movementStatus;
}EveBotPrintHead;

typedef struct __pastryData{
	//centre coords
	uint16_t coordX; //8-9  response bits
	uint16_t coordY; //10-11 response bits
	//dimensions
	uint16_t height;
	uint16_t width;
	//bottom line
	uint16_t bottomY;
	uint16_t topY;
	int actualDistanceX;
	uint16_t objectID;

} PastryData;


typedef struct __row{
	uint16_t coordRow_Y;
	uint16_t numberOfRowObjects;
	uint16_t coordXArray[10];
}Row;
/*
 *@desc Set the dimensions accordingly (manually, for testing purposes)
 *@desc For conversion from pixels to actual distance (in mm)
 *@desc dimensions are in mm
 */
typedef struct __cameraRatio{
	int actualObjectWidth;
	int pxObjectWidth;
}CameraRatio;

Row row; // number of rows

PastryData pastry[6]; //max no of objects

uint16_t finalPush = 0;
PixyChecksumState checkSumCalculator(uint8_t* array);

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define SPI_BUFFER_SIZE 300
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi2;

TIM_HandleTypeDef htim1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
uint8_t spiRxBuffer[SPI_BUFFER_SIZE];
uint8_t spiTxBuffer[SPI_BUFFER_SIZE];

uint8_t getVersion[] = {
  0xae,
  0xc1,
  0x0e,
  0x00,
};

uint8_t getBlocks[] = {
  0xae, //175
  0xc1, //193
  0x20, //type of packet - getBlocks Request 32 dec 0x20 Hex
  0x02, // payload (below length) 0x02
  0xFF, // get all signatures recognised
  0x06 // number of blocks x4
};

uint8_t setLamp[] = {
  0xae, //175
  0xc1, //193
  0x16,
  0x02,
  0x01
};



EveBotPrintHead printHeadMovement = {
		.movementStatus = IDLE
};
uint8_t* responsePacketStart;

/*
 *@desc Set the dimensions accordingly (manually, for testing purposes)
 *@desc For conversion from pixels to actual distance (in mm)
 *@desc dimensions are in mm
 *@param actualObjectWidth - actual width of the object
 *@param pxObjectWidth - manually measured pixel width from pixy camera
 */
CameraRatio camRatio = {
	.actualObjectWidth = 1,
	.pxObjectWidth = 1
};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM1_Init(void);
static void MX_SPI2_Init(void);
/* USER CODE BEGIN PFP */
/**
 *	@desc Calculates the steps required given an x mm distance. 40 steps required to travel 1 mm
 *	@desc Does 400 iterations, of alternating high and low pulse i.e. 200 steps for one revolution
 */
int distCal(int distance);//in mm
/**
 *	@desc Compute the distance in mm based on pixels from pixy Camera
 */
int computePixyXDistance(PastryData* pastry, CameraRatio* ratio);
/**
 *	@desc blocking microsecond delay
 */
void microDelay (uint16_t delay);
/**
 *	@desc Does the printing routine. GO FRONT, then GO RETRACT/GO BACK.
 */
void iniDelay(void);
/**
 *	@desc Print SPI buffer in full
 */
void printBuffer(uint8_t* buffer);
/**
 *	@desc Checks for start response byte to commence checksum routine
 */
uint8_t* tpixCheckStartCmd(uint8_t* spiRxBuffer);
/**
 *	@desc Retrieves the details of blocks
 */
void retrieveGetBlocks(uint8_t* spiRxBuffer);
/**
 *	@desc A routine that moves the printhead to the printing zone before commencing printing routine
 */
void moveToSetDistance();
/**
 *	@desc Retrieves the coordinates of blocks detected
 */
void retrieveGetBlocks(uint8_t* spiRxBuffer);
/**
 *	@desc Number of blocks/colours
 */
uint8_t numberOfBlocks;
/**
 *	@desc For debugging: Tracks the checksum of the incoming response packet.
 */
PixyChecksumState checkSumStatus;
/**
 *	@desc Will only be executed if conveyer stepper stops and upon detection of pixy colour blocks
 */
void printHeadMovementRoutine();
/**
 *	@desc Movement of Motor with Pixy camera
 */
void printHeadMovementWithPixy();

void createRows();

void testmovement(int z);

void moveBottom();

void movePrint();
int stepDelay = 500; // SPEED, 1000us more delay means less speed


void swap(uint16_t *xp, uint16_t *yp);

// Function to perform Bubble Sort
void bubbleSort(uint16_t arr[], int n);

void conveyerDCTest();

void conveyerStepperTest();


uint8_t y = 0;
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM1_Init();
  MX_SPI2_Init();
  /* USER CODE BEGIN 2 */

	HAL_Delay(1000);

	HAL_GPIO_WritePin(DIR_PORT, DIR_PIN, GPIO_PIN_SET);
	HAL_GPIO_WritePin(STEP_PORT, STEP_PIN, GPIO_PIN_SET);
	HAL_TIM_Base_Start(&htim1);
	HAL_Delay(10);
//	HAL_SPI_Transmit(&hspi2, setLamp, 5, 100);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

	/**
	 *Pixy Control starts here
	 */
    HAL_SPI_Transmit(&hspi2, getBlocks, 6, 100);
    HAL_Delay(100);
	HAL_SPI_Receive(&hspi2, spiRxBuffer, SPI_BUFFER_SIZE, 100);
	uint8_t* startingResponsePtr = tpixCheckStartCmd(spiRxBuffer);
	if(startingResponsePtr == NULL){
		continue; // skip
	}
	checkSumStatus = checkSumCalculator(startingResponsePtr);
	if(checkSumStatus == PIXY_RESULT_OK){
		retrieveGetBlocks(startingResponsePtr);
		createRows();
//		testmovement((row.coordXArray[1] - row.coordXArray[0]) * 1.5);
		printHeadMovementRoutine();
		while(1){
			//do nothing
		}
//		movePrint();
	}else if(checkSumStatus == PIXY_RESULT_ERROR){
		//do nothing
	}
	/**
	 * Pixy END
	 * */

	//START MOVEMENT LOGIC

	//iniDelay();
//	testmovement(50);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_HIGH;
  hspi2.Init.CLKPhase = SPI_PHASE_2EDGE;
  hspi2.Init.NSS = SPI_NSS_HARD_OUTPUT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_32;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 71;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 3599;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0|GPIO_PIN_1|LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PA0 PA1 LD2_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	if(GPIO_Pin == B1_Pin){
	  	HAL_GPIO_TogglePin(DIR_PORT, DIR_PIN);
	}
}
void microDelay (uint16_t delay)
{
__HAL_TIM_SET_COUNTER(&htim1, 0);
while (__HAL_TIM_GET_COUNTER(&htim1) < delay);
}

int distCal(int distance)//in mm
{
	int value = distance * 400/40;
	return value;
}

void iniDelay(void)
{
	int x;
	int dist = distCal(INIDIST/2);
	int speed = 1000;
	for(x=0; x<dist; ++x)
	{
		HAL_GPIO_TogglePin(STEP_PORT, STEP_PIN);
		microDelay(speed);
	}
  	HAL_GPIO_TogglePin(DIR_PORT, DIR_PIN);
	for(x=0; x<dist; ++x)
	{
		HAL_GPIO_TogglePin(STEP_PORT, STEP_PIN);
		microDelay(speed);
	}
  	HAL_GPIO_TogglePin(DIR_PORT, DIR_PIN);
}



PixyChecksumState checkSumCalculator(uint8_t* array)//calculate checksum of pixycam
{
	uint16_t size = array[3];
	size = size + 6;//including header bytes
	uint16_t checksum = array[5] << 8 | array[4];
	uint16_t cal_checksum = 0;
	for(int i = 6; i<size;i++)
	{
		cal_checksum+=array[i];
	}
	return checksum==cal_checksum?PIXY_RESULT_OK:PIXY_RESULT_ERROR;
}

uint8_t* tpixCheckStartCmd(uint8_t* spiRxBuffer) {
    for(int index = 0; index < SPI_BUFFER_SIZE; ++index){
        //search for the first occurence
        //the
        if (spiRxBuffer[index] == 0xAF && spiRxBuffer[index + 1] == 0xC1) {
            // Point rx spi buffer pointer to start of AF_C1 bytes
        	// retrieve the address of the response packet along the SPI Buffer
        	responsePacketStart = &(spiRxBuffer[index]);
            return responsePacketStart;
        }
    }
//    printf("AF header byte not found in rx SPI buffer\r\n");
    return NULL;
}

//void retrieveGetBlocks(uint8_t* spiRxBuffer, PastryData* pastryArray, uint16_t pastryArrayLength, uint8_t* rxBufferSize){
void retrieveGetBlocks(uint8_t* spiRxBuffer){
	uint8_t* responsePacketPtr = spiRxBuffer; // prevent overwriting of main buffer pointer
	if(responsePacketPtr != NULL){
		//retrieve
		numberOfBlocks = responsePacketPtr[3] / 14;
		int pasPosX = 8;
		int pasPosY = 10;

		for(int i = 0; i<numberOfBlocks; ++i, pasPosX+=14, pasPosY+=14)//loop for the no objects
		{
			pastry[i].coordX = responsePacketPtr[pasPosX+1] << 8 | responsePacketPtr[pasPosX];
			pastry[i].coordY = responsePacketPtr[pasPosY+1] << 8 | responsePacketPtr[pasPosY];
			pastry[i].width = responsePacketPtr[pasPosY+5] << 8 | responsePacketPtr[pasPosY+4];
			pastry[i].height = responsePacketPtr[pasPosX+7] << 8 | responsePacketPtr[pasPosX+6];
			pastry[i].objectID =  responsePacketPtr[pasPosY+8];
			pastry[i].bottomY = pastry[i].coordY + (pastry[i].height/2);
			pastry[i].topY = pastry[i].coordY - (pastry[i].height/2);
			pastry[i].actualDistanceX = computePixyXDistance(&pastry[i], &camRatio);
		}
//		printf("Number of blocks: %d \r\n", numberOfBlocks);
	}else{
//		printf("Response invalid! Trying in next iteration\r\n");
	}
}


void printBuffer(uint8_t* buffer){
	uint8_t indx = *buffer;
	if(indx != 0){
//		printf("Buffer empty\r\n");
		return;
	}
	while((char) *buffer != '\0'){
//		printf("%c\r\n", *buffer);
	}
}
void printHeadMovementRoutine(){
	/**
	 *Motor Routine starts here
	 *Future plans may offload motor control to other peripheral e.g. DMA
	 */
    int dist;
    int offset = PRINTSIZE/2;
    int datum = DATUM+offset;
    int move = 400;


    for(int i = 0; i< row.numberOfRowObjects; i++)
    {
    	int dist = distCal((row.coordXArray[i]- datum) * PIXY_RATIO);
        for(int x =0; x<dist;++x)
        {
    		HAL_GPIO_TogglePin(STEP_PORT, STEP_PIN);
    		microDelay(stepDelay);
        }
        HAL_Delay(5000);
        //button press
        iniDelay();//does the printing movement. GO FRONT - GO BACK
        //movement
//        for(int x =0; x<move;++x)
//        {
//    		HAL_GPIO_TogglePin(STEP_PORT, STEP_PIN);
//    		microDelay(stepDelay);
//        }
        HAL_Delay(1000);
        testmovement(PRINTSIZE);
        HAL_Delay(5000);
        datum = row.coordXArray[i] + (PRINTSIZE-offset); // + (10/1.5);
    }
    //moves to set distance


	/**
	 *Motor Routine ends here
	 *Future plans may offload motor control to other peripheral e.g. DMA
	 */
}


void testmovement(int z){
	/**
	 *Motor Routine starts here
	 *Future plans may offload motor control to other peripheral e.g. DMA
	 */

//	iniDelay();
    int dist = distCal(z);
    //moves to set distance
    for(int x =0; x<dist;++x)
    {
		HAL_GPIO_TogglePin(STEP_PORT, STEP_PIN);
		microDelay(stepDelay);
    }
//    HAL_Delay(1000);
//    while(1)
//    {
//
//    }
    //does the printing movement. GO FRONT - GO BACK

	/**
	 *Motor Routine ends here
	 *Future plans may offload motor control to other peripheral e.g. DMA
	 */
}

void printHeadMovementWithPixy(){
	int dist[numberOfBlocks];
	for(int x = 0; x < numberOfBlocks; ++x){
		dist[x] = distCal(pastry[x].actualDistanceX);
	}
	int deliverPointsIndex = 0;
	while(deliverPointsIndex < numberOfBlocks){
	    for(int x =0; x<dist[deliverPointsIndex];++x)
	    {
			HAL_GPIO_TogglePin(STEP_PORT, STEP_PIN);
			microDelay(stepDelay);
	    }
	    HAL_Delay(500);
		deliverPointsIndex++;
		iniDelay();
		HAL_Delay(500);
	}
}
int computePixyXDistance(PastryData* pastry, CameraRatio* ratio){
	int pixelXDistance = (int) pastry->coordX; //assume camera is on the left
//	int pixelXDistance = 315 - (int) pastry->coordX; //assume camera is on the right
	if(pastry == NULL){
		return -1;
	}else{
		return (pixelXDistance/ratio->pxObjectWidth) * ratio->actualObjectWidth;
	}
}

//Stores ROW, number of objects on the ROW, and Coordinates on the ROW
void createRows()
{
	//find ROW
	uint16_t rowval = 0;
	for(int j = 0; j<sizeof(pastry)/sizeof(PastryData); ++j)
	{
		if(pastry[j].coordY > rowval && pastry[j].bottomY<= EVENT_HORIZON)//checks for lowest legal point for row
		{
			rowval = pastry[j].coordY;
		}
	}
	//Reset OBJECTS
	row.coordRow_Y = PRINT_LINE - rowval; //stores the distance from the center to the print line.
	row.numberOfRowObjects = 0;
	for (int i = 0; i< 10; i++)
	{
		row.coordXArray[i] = 400;
	}
	//Calibrate Objects
	for(int i = 0; i< numberOfBlocks; ++i)//loop for the no objects
	{
		if(row.coordRow_Y + 5 >= pastry[i].coordY || row.coordRow_Y - 5 <= pastry[i].coordY){
			row.coordXArray[i] = pastry[i].coordX;
			row.numberOfRowObjects++;
		}
	}
	bubbleSort(row.coordXArray, 10);
}

void moveBottom()
{
	//MOVE CONVETPR TILL THE bottomY touches the print line
	//store remain value to finalPUSH
}

void movePrint()
{
	//Move for finalPUSH
	//print on objects
	printHeadMovementRoutine();
}




// Function to swap two elements
void swap(uint16_t *xp, uint16_t *yp) {
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}

// Function to perform Bubble Sort
void bubbleSort(uint16_t arr[], int n) {
    int i, j;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                swap(&arr[j], &arr[j + 1]);
            }
        }
    }
}
void conveyerDCTest(){
//D10 PWM
//D11 INPUT 1
//D12 INPUT 2
//110

}

void conveyerStepperTest(){

}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
